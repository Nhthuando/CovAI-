import { test, expect } from '@playwright/test';

test.describe('Online Food Ordering System', () => {
  test('READ - View empty cart drawer', async ({ page }) => {
    await test.step('Setup: Navigate to home page', async () => {
      await page.goto('/');
      await expect(page.getByRole('heading', { level: 1, name: 'MENU' })).toBeVisible();
    });

    await test.step('Action: READ - Open shopping cart drawer when empty', async () => {
      await page.getByRole('button', { name: '🛒' }).click();
    });

    await test.step('Assert: Empty cart message is visible in drawer', async () => {
      await expect(page.getByRole('heading', { level: 1, name: 'Giỏ hàng' })).toBeVisible();
      await expect(page.getByText('Chưa có sản phẩm trong giỏ.')).toBeVisible();
    });

    await test.step('Evidence: verified outcome', async () => {
      await test.info().attach('evidence', {
        body: await page.screenshot(),
        contentType: 'image/png',
      });
    });
  });

  test('NAVIGATION - View food details from menu card', async ({ page, request }) => {
    let createdFood;
    const uniqueName = `Pho Bo Navigation ${Date.now()}`;

    try {
      await test.step('Setup: Create food item and open menu', async () => {
        const response = await request.post('/api/food-items/create/', {
          data: {
            name: uniqueName,
            image: 'https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43',
            price: 65000,
            rating: 4.5,
            description: 'Delicious hot broth with tender beef slices',
            category: 'Noodles',
            isAvailable: 'true',
          },
        });
        expect(response.ok()).toBeTruthy();
        createdFood = await response.json();

        await page.goto('/');
        await expect(page.getByRole('heading', { level: 3, name: uniqueName })).toBeVisible();
      });

      await test.step('Action: NAVIGATION - Click view details button on food item card', async () => {
        const foodCard = page.locator('div.bg-gray-800').filter({
          has: page.getByRole('heading', { level: 3, name: uniqueName }),
        });
        await foodCard.getByRole('button', { name: 'Xem chi tiết' }).click();
      });

      await test.step('Assert: Food detail page is displayed with item info', async () => {
        await expect(page).toHaveURL(new RegExp(`/food/${createdFood.id}`));
        await expect(page.getByRole('heading', { level: 1, name: uniqueName })).toBeVisible();
        await expect(page.getByText('Delicious hot broth with tender beef slices')).toBeVisible();
        await expect(page.getByRole('button', { name: 'Thêm vào giỏ' })).toBeVisible();
      });

      await test.step('Evidence: verified outcome', async () => {
        await test.info().attach('evidence', {
          body: await page.screenshot(),
          contentType: 'image/png',
        });
      });
    } finally {
      if (createdFood?.id) {
        await test.step('Cleanup: Remove prerequisite food item', async () => {
          await request.delete(`/api/food-items/delete/${createdFood.id}`);
        });
      }
    }
  });

  test('CREATE - Add food item to shopping cart', async ({ page, request }) => {
    let createdFood;
    const uniqueName = `Banh Mi Cart Add ${Date.now()}`;

    try {
      await test.step('Setup: Create food item and visit detail page', async () => {
        const response = await request.post('/api/food-items/create/', {
          data: {
            name: uniqueName,
            image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c',
            price: 35000,
            rating: 5,
            description: 'Crispy Vietnamese baguette sandwich',
            category: 'Snacks',
            isAvailable: 'true',
          },
        });
        expect(response.ok()).toBeTruthy();
        createdFood = await response.json();

        await page.goto(`/food/${createdFood.id}`);
        await expect(page.getByRole('heading', { level: 1, name: uniqueName })).toBeVisible();
      });

      await test.step('Action: CREATE - Add food item to cart', async () => {
        await page.getByRole('button', { name: 'Thêm vào giỏ' }).click();
      });

      await test.step('Assert: Success toast is displayed and cart item persists', async () => {
        await expect(page.getByText('Đã thêm vào giỏ hàng!')).toBeVisible();

        await page.goto('/');
        const cartButton = page.getByRole('button', { name: '🛒' });
        await expect(cartButton.locator('span')).toHaveText('1');

        await page.reload();
        await expect(cartButton.locator('span')).toHaveText('1');
      });

      await test.step('Evidence: verified outcome', async () => {
        await test.info().attach('evidence', {
          body: await page.screenshot(),
          contentType: 'image/png',
        });
      });
    } finally {
      if (createdFood?.id) {
        await test.step('Cleanup: Remove prerequisite food item', async () => {
          await request.delete(`/api/food-items/delete/${createdFood.id}`);
        });
      }
    }
  });

  test('UPDATE - Modify food item quantity in cart', async ({ page, request }) => {
    let createdFood;
    const uniqueName = `Bun Cha Update ${Date.now()}`;
    const itemPrice = 50000;

    try {
      await test.step('Setup: Create food, add to cart and open cart drawer', async () => {
        const response = await request.post('/api/food-items/create/', {
          data: {
            name: uniqueName,
            image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624',
            price: itemPrice,
            rating: 4.8,
            description: 'Grilled pork with rice vermicelli',
            category: 'Noodles',
            isAvailable: 'true',
          },
        });
        expect(response.ok()).toBeTruthy();
        createdFood = await response.json();

        await page.goto(`/food/${createdFood.id}`);
        await page.getByRole('button', { name: 'Thêm vào giỏ' }).click();
        await expect(page.getByText('Đã thêm vào giỏ hàng!')).toBeVisible();

        await page.goto('/');
        await page.getByRole('button', { name: '🛒' }).click();
        await expect(page.getByRole('heading', { level: 1, name: 'Giỏ hàng' })).toBeVisible();
      });

      await test.step('Action: UPDATE - Change food quantity in cart drawer', async () => {
        const itemRow = page.getByRole('dialog').locator('div.bg-gray-800').filter({ hasText: uniqueName });
        const quantityInput = itemRow.locator('input[type="number"]');
        await quantityInput.fill('3');
      });

      await test.step('Assert: Total price updates and quantity persists after reload', async () => {
        const itemRow = page.getByRole('dialog').locator('div.bg-gray-800').filter({ hasText: uniqueName });
        const expectedSubtotal = `${(itemPrice * 3).toLocaleString()} VNĐ`;
        await expect(itemRow.getByText(expectedSubtotal, { exact: true })).toBeVisible();

        await page.reload();
        await page.getByRole('button', { name: '🛒' }).click();
        const reloadedRow = page.getByRole('dialog').locator('div.bg-gray-800').filter({ hasText: uniqueName });
        await expect(reloadedRow.locator('input[type="number"]')).toHaveValue('3');
      });

      await test.step('Evidence: verified outcome', async () => {
        await test.info().attach('evidence', {
          body: await page.screenshot(),
          contentType: 'image/png',
        });
      });
    } finally {
      if (createdFood?.id) {
        await test.step('Cleanup: Remove prerequisite food item', async () => {
          await request.delete(`/api/food-items/delete/${createdFood.id}`);
        });
      }
    }
  });

  test('DELETE - Remove item from cart drawer', async ({ page, request }) => {
    let createdFood;
    const uniqueName = `Com Tam Delete ${Date.now()}`;

    try {
      await test.step('Setup: Create food, add to cart and open cart drawer', async () => {
        const response = await request.post('/api/food-items/create/', {
          data: {
            name: uniqueName,
            image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c',
            price: 45000,
            rating: 4.7,
            description: 'Broken rice with pork chop',
            category: 'Rice',
            isAvailable: 'true',
          },
        });
        expect(response.ok()).toBeTruthy();
        createdFood = await response.json();

        await page.goto(`/food/${createdFood.id}`);
        await page.getByRole('button', { name: 'Thêm vào giỏ' }).click();
        await expect(page.getByText('Đã thêm vào giỏ hàng!')).toBeVisible();

        await page.goto('/');
        await page.getByRole('button', { name: '🛒' }).click();
        await expect(page.getByRole('dialog').getByText(uniqueName)).toBeVisible();
      });

      await test.step('Action: DELETE - Remove item from cart', async () => {
        const itemRow = page.getByRole('dialog').locator('div.bg-gray-800').filter({ hasText: uniqueName });
        await itemRow.getByRole('button', { name: 'Xóa' }).click();
      });

      await test.step('Assert: Item is removed and cart is empty', async () => {
        await expect(page.getByRole('dialog').getByText(uniqueName)).not.toBeVisible();
        await expect(page.getByText('Chưa có sản phẩm trong giỏ.')).toBeVisible();

        await page.reload();
        await page.getByRole('button', { name: '🛒' }).click();
        await expect(page.getByText('Chưa có sản phẩm trong giỏ.')).toBeVisible();
      });

      await test.step('Evidence: verified outcome', async () => {
        await test.info().attach('evidence', {
          body: await page.screenshot(),
          contentType: 'image/png',
        });
      });
    } finally {
      if (createdFood?.id) {
        await test.step('Cleanup: Remove prerequisite food item', async () => {
          await request.delete(`/api/food-items/delete/${createdFood.id}`);
        });
      }
    }
  });

  test('VALIDATION - Validate receiver information required fields during checkout', async ({ page, request }) => {
    let createdFood;
    let dialogMessage = '';
    const uniqueName = `Goi Cuon Valid ${Date.now()}`;

    try {
      await test.step('Setup: Create food, add to cart, open cart and start checkout', async () => {
        const response = await request.post('/api/food-items/create/', {
          data: {
            name: uniqueName,
            image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c',
            price: 30000,
            rating: 4.6,
            description: 'Fresh spring rolls with shrimp',
            category: 'Snacks',
            isAvailable: 'true',
          },
        });
        expect(response.ok()).toBeTruthy();
        createdFood = await response.json();

        await page.goto(`/food/${createdFood.id}`);
        await page.getByRole('button', { name: 'Thêm vào giỏ' }).click();
        await expect(page.getByText('Đã thêm vào giỏ hàng!')).toBeVisible();

        await page.goto('/');
        await page.getByRole('button', { name: '🛒' }).click();
        await page.getByRole('button', { name: 'Thanh toán' }).click();
        await expect(page.getByRole('heading', { level: 2, name: 'Thông tin người nhận' })).toBeVisible();
      });

      await test.step('Action: VALIDATION - Submit empty receiver information form', async () => {
        page.once('dialog', async (dialog) => {
          dialogMessage = dialog.message();
          await dialog.accept();
        });
        await page.getByRole('button', { name: 'Tiếp tục' }).click();
      });

      await test.step('Assert: Validation alert is triggered and receiver form persists', async () => {
        expect(dialogMessage).toContain('Vui lòng điền đầy đủ thông tin người nhận!');
        await expect(page.getByRole('heading', { level: 2, name: 'Thông tin người nhận' })).toBeVisible();
      });

      await test.step('Evidence: verified outcome', async () => {
        await test.info().attach('evidence', {
          body: await page.screenshot(),
          contentType: 'image/png',
        });
      });
    } finally {
      if (createdFood?.id) {
        await test.step('Cleanup: Remove prerequisite food item', async () => {
          await request.delete(`/api/food-items/delete/${createdFood.id}`);
        });
      }
    }
  });
});

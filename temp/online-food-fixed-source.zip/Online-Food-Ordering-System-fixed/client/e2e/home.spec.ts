import { test, expect } from '@playwright/test';

test.describe('Online Food Ordering - System & E2E Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Intercept backend API calls so E2E tests are 100% reliable and independent of external Render server
    await page.route('**/api/food-items*', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          data: [
            {
              id: 1,
              name: 'Pizza Margherita',
              price: 150000,
              rating: 4.5,
              image: '/pizza.jpg',
              category: 'Pizza',
              isAvailable: true,
            },
            {
              id: 2,
              name: 'Burger Deluxe',
              price: 75000,
              rating: 4.8,
              image: '/burger.jpg',
              category: 'Burger',
              isAvailable: true,
            },
          ],
          total: 2,
          page: 1,
          totalPages: 1,
        }),
      });
    });
  });

  test('homepage has expected title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Online Food Ordering/);
  });

  test('homepage renders main root container and content', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('#root')).toBeVisible();
    await expect(page.locator('body')).toBeVisible();
    await expect(page.locator('h1', { hasText: 'MENU' })).toBeVisible();
  });

  test('food items are rendered on homepage', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('text=Pizza Margherita')).toBeVisible();
    await expect(page.locator('text=Burger Deluxe')).toBeVisible();
  });

  test('floating cart button is displayed on homepage', async ({ page }) => {
    await page.goto('/');
    const cartButton = page.locator('button', { hasText: '🛒' });
    await expect(cartButton).toBeVisible();
  });

  test('clicking cart button opens and closes the cart drawer', async ({ page }) => {
    await page.goto('/');

    // Click cart button (force: true because framer-motion has continuous pulse animation)
    const cartButton = page.locator('button', { hasText: '🛒' });
    await cartButton.click({ force: true });

    // Verify cart drawer heading is visible
    const cartHeading = page.locator('h1', { hasText: 'Giỏ hàng' });
    await expect(cartHeading).toBeVisible();

    // Check empty cart message
    const emptyMessage = page.locator('text=Chưa có sản phẩm trong giỏ.');
    await expect(emptyMessage).toBeVisible();

    // Wait for the slide-in spring animation to settle into viewport before clicking close
    const closeButton = page.locator('button', { hasText: '✕' });
    await expect(closeButton).toBeInViewport();
    await closeButton.click();

    // Verify cart drawer is dismissed
    await expect(cartHeading).not.toBeVisible();
  });

  test('payment success page renders successfully', async ({ page }) => {
    await page.goto('/payment-success');
    await expect(page.locator('text=Thanh toán thành công!')).toBeVisible();
    await expect(page.locator('text=Quay về trang chủ')).toBeVisible();
  });
});

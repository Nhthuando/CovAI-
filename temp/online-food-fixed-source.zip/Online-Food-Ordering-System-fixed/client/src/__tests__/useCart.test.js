import { renderHook, act } from "@testing-library/react";
import { useCart } from "../hook/useCart";

describe("useCart Hook Unit Tests", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("should initialize with an empty cart when localStorage is empty", () => {
    const { result } = renderHook(() => useCart());
    expect(result.current.cart).toEqual([]);
  });

  it("should initialize with saved cart items from localStorage", () => {
    const savedItems = [{ id: 1, name: "Burger", price: 50000, quantity: 2 }];
    localStorage.setItem("cart", JSON.stringify(savedItems));

    const { result } = renderHook(() => useCart());
    expect(result.current.cart).toEqual(savedItems);
  });

  it("should add a new food item to the cart with quantity 1", () => {
    const { result } = renderHook(() => useCart());
    const food = { id: 10, name: "Pizza", price: 120000, image: "/pizza.jpg" };

    act(() => {
      result.current.addToCart(food);
    });

    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cart[0]).toEqual({
      id: 10,
      name: "Pizza",
      price: 120000,
      image: "/pizza.jpg",
      quantity: 1,
    });
    expect(JSON.parse(localStorage.getItem("cart"))).toHaveLength(1);
  });

  it("should increment quantity when adding an item that is already in cart", () => {
    const { result } = renderHook(() => useCart());
    const food = { id: 10, name: "Pizza", price: 120000, image: "/pizza.jpg" };

    act(() => {
      result.current.addToCart(food);
    });
    act(() => {
      result.current.addToCart(food);
    });

    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cart[0].quantity).toBe(2);
  });

  it("should update quantity of an existing item", () => {
    const { result } = renderHook(() => useCart());
    const food = { id: 10, name: "Pizza", price: 120000, image: "/pizza.jpg" };

    act(() => {
      result.current.addToCart(food);
    });
    act(() => {
      result.current.updateQuantity(10, 5);
    });

    expect(result.current.cart[0].quantity).toBe(5);
  });

  it("should ignore updateQuantity if quantity <= 0", () => {
    const { result } = renderHook(() => useCart());
    const food = { id: 10, name: "Pizza", price: 120000, image: "/pizza.jpg" };

    act(() => {
      result.current.addToCart(food);
    });
    act(() => {
      result.current.updateQuantity(10, 0);
    });

    expect(result.current.cart[0].quantity).toBe(1);
  });

  it("should remove item from cart by id", () => {
    const { result } = renderHook(() => useCart());
    const food1 = { id: 1, name: "Item 1", price: 10000 };
    const food2 = { id: 2, name: "Item 2", price: 20000 };

    act(() => {
      result.current.addToCart(food1);
      result.current.addToCart(food2);
    });
    expect(result.current.cart).toHaveLength(2);

    act(() => {
      result.current.removeFromCart(1);
    });

    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cart[0].id).toBe(2);
  });

  it("should clear all items from the cart", () => {
    const { result } = renderHook(() => useCart());
    act(() => {
      result.current.addToCart({ id: 1, name: "Item 1", price: 10000 });
      result.current.addToCart({ id: 2, name: "Item 2", price: 20000 });
    });
    expect(result.current.cart).toHaveLength(2);

    act(() => {
      result.current.clearCart();
    });

    expect(result.current.cart).toEqual([]);
    expect(JSON.parse(localStorage.getItem("cart"))).toEqual([]);
  });
});

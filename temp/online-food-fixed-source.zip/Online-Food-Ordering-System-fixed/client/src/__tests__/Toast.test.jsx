import { render, screen, act } from "@testing-library/react";
import Toast from "../components/Toast";

describe("Toast Component Unit Tests", () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it("should render toast message correctly", () => {
    const handleClose = jest.fn();
    render(
      <Toast
        message="Item added to cart!"
        status="success"
        onClose={handleClose}
      />,
    );

    expect(screen.getByText("Item added to cart!")).toBeTruthy();
  });

  it("should apply green background for success status", () => {
    const handleClose = jest.fn();
    render(
      <Toast
        message="Success message"
        status="success"
        onClose={handleClose}
      />,
    );

    const toastElement = screen.getByText("Success message");
    expect(toastElement.className).toContain("bg-green-500");
  });

  it("should apply red background for error status", () => {
    const handleClose = jest.fn();
    render(
      <Toast message="Error message" status="error" onClose={handleClose} />,
    );

    const toastElement = screen.getByText("Error message");
    expect(toastElement.className).toContain("bg-red-500");
  });

  it("should auto-close after specified duration", () => {
    const handleClose = jest.fn();
    render(
      <Toast message="Timer message" duration={2000} onClose={handleClose} />,
    );

    expect(handleClose).not.toHaveBeenCalled();

    act(() => {
      jest.advanceTimersByTime(2000);
    });

    expect(handleClose).toHaveBeenCalledTimes(1);
  });
});

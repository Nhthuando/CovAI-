import { validateCart, checkout, createPaymentIntent } from "../service/api";

describe("Client API Service", () => {
  const mockFetch = jest.fn();
  global.fetch = mockFetch;

  beforeEach(() => {
    mockFetch.mockClear();
  });

  it("validateCart should POST cart items", async () => {
    const mockResponse = { success: true, items: [], totalPrice: 0 };
    mockFetch.mockResolvedValueOnce({
      json: jest.fn().mockResolvedValueOnce(mockResponse),
    });

    const cart = [{ foodId: 1, quantity: 2 }];
    const result = await validateCart(cart);

    expect(mockFetch).toHaveBeenCalledWith(
      expect.stringContaining("/api/cart/validate"),
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ items: cart }),
      })
    );
    expect(result).toEqual(mockResponse);
  });

  it("checkout should POST order payload", async () => {
    const mockResponse = { success: true, order: { id: "ord_1" } };
    mockFetch.mockResolvedValueOnce({
      json: jest.fn().mockResolvedValueOnce(mockResponse),
    });

    const payload = { items: [], paymentIntentId: "pi_123", totalPaid: 1000 };
    const result = await checkout(payload);

    expect(mockFetch).toHaveBeenCalledWith(
      expect.stringContaining("/api/cart/checkout"),
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify(payload),
      })
    );
    expect(result).toEqual(mockResponse);
  });

  it("createPaymentIntent should POST amount", async () => {
    const mockResponse = { clientSecret: "pi_sec_1" };
    mockFetch.mockResolvedValueOnce({
      json: jest.fn().mockResolvedValueOnce(mockResponse),
    });

    const result = await createPaymentIntent(50000);

    expect(mockFetch).toHaveBeenCalledWith(
      expect.stringContaining("/api/payments/create-payment-intent"),
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ amount: 50000 }),
      })
    );
    expect(result).toEqual(mockResponse);
  });
});


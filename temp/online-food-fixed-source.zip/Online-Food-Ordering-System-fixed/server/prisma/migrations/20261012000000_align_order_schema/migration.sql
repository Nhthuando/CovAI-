ALTER TABLE `Order`
  CHANGE COLUMN `total` `totalVnd` INTEGER NOT NULL,
  CHANGE COLUMN `paymentId` `paymentIntentId` VARCHAR(191) NULL,
  ADD COLUMN `totalPaid` INTEGER NULL,
  ADD COLUMN `currency` VARCHAR(191) NULL,
  ADD COLUMN `paymentMethod` VARCHAR(191) NOT NULL DEFAULT 'stripe',
  ADD COLUMN `paymentStatus` VARCHAR(191) NOT NULL DEFAULT 'pending';

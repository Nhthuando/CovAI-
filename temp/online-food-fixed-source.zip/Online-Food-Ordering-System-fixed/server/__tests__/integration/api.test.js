const request = require("supertest");
const app = require("../../index");
const productService = require("../../services/productService");
const { PrismaClient } = require("@prisma/client");
const Stripe = require("stripe");

jest.mock("stripe", () => {
  return jest.fn(() => ({
    checkout: {
      sessions: {
        create: jest
          .fn()
          .mockResolvedValue({ url: "https://stripe.test/session" }),
      },
    },
    paymentIntents: {
      create: jest
        .fn()
        .mockResolvedValue({ client_secret: "pi_secret_test123" }),
    },
  }));
});

jest.mock("@prisma/client", () => {
  const mPrisma = {
    food: {
      findUnique: jest.fn(),
    },
    order: {
      create: jest.fn(),
    },
    $connect: jest.fn().mockResolvedValue(true),
  };
  return { PrismaClient: jest.fn(() => mPrisma) };
});

const prisma = new PrismaClient();

describe("Full API Integration Tests (Supertest)", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe("Health Check", () => {
    it("GET / should return 200 and running text", async () => {
      const res = await request(app).get("/");
      expect(res.statusCode).toBe(200);
      expect(res.text).toBe("API server is running...");
    });
  });

  describe("Food Items API (/api/food-items)", () => {
    it("GET /api/food-items should return list of foods", async () => {
      jest.spyOn(productService, "listFoodItems").mockResolvedValue({
        data: [{ id: 1, name: "Burger", price: 50000 }],
        total: 1,
        page: 1,
        totalPages: 1,
      });

      const res = await request(app).get("/api/food-items");
      expect(res.statusCode).toBe(200);
      expect(res.body.data).toHaveLength(1);
      expect(res.body.data[0].name).toBe("Burger");
    });

    it("GET /api/food-items with search and category queries", async () => {
      const mockList = jest
        .spyOn(productService, "listFoodItems")
        .mockResolvedValue({
          data: [],
          total: 0,
          page: 1,
          totalPages: 0,
        });

      const res = await request(app).get(
        "/api/food-items?search=pizza&category=fastfood",
      );
      expect(res.statusCode).toBe(200);
      expect(mockList).toHaveBeenCalledWith(
        expect.objectContaining({ search: "pizza", category: "fastfood" }),
      );
    });

    it("GET /api/food-items/get/:id should return single food item", async () => {
      jest.spyOn(productService, "getFoodItemById").mockResolvedValue({
        id: 1,
        name: "Burger",
        price: 50000,
      });

      const res = await request(app).get("/api/food-items/get/1");
      expect(res.statusCode).toBe(200);
      expect(res.body.name).toBe("Burger");
    });

    it("GET /api/food-items/get/:id should return 404 when item not found", async () => {
      jest.spyOn(productService, "getFoodItemById").mockResolvedValue(null);

      const res = await request(app).get("/api/food-items/get/999");
      expect(res.statusCode).toBe(404);
      expect(res.body.message).toBe("Food item not found");
    });

    it("POST /api/food-items/create/ should create food item with status 201", async () => {
      const newFood = {
        name: "Fried Chicken",
        price: 70000,
        category: "Fast Food",
      };
      jest
        .spyOn(productService, "createFoodItem")
        .mockResolvedValue({ id: 5, ...newFood });

      const res = await request(app)
        .post("/api/food-items/create/")
        .send(newFood);
      expect(res.statusCode).toBe(201);
      expect(res.body.id).toBe(5);
      expect(res.body.name).toBe("Fried Chicken");
    });

    it("PUT /api/food-items/update/:id should update food item", async () => {
      const updateData = { price: 75000 };
      jest
        .spyOn(productService, "updateFoodItem")
        .mockResolvedValue({ id: 5, ...updateData });

      const res = await request(app)
        .put("/api/food-items/update/5")
        .send(updateData);
      expect(res.statusCode).toBe(200);
      expect(res.body.price).toBe(75000);
    });

    it("DELETE /api/food-items/delete/:id should delete food item", async () => {
      jest.spyOn(productService, "deleteFoodItem").mockResolvedValue({});

      const res = await request(app).delete("/api/food-items/delete/5");
      expect(res.statusCode).toBe(200);
      expect(res.body.message).toBe("Food item deleted successfully");
    });
  });

  describe("Cart & Order API (/api/cart)", () => {
    it("POST /api/cart/validate should validate cart items", async () => {
      prisma.food.findUnique.mockResolvedValueOnce({
        id: 1,
        name: "Burger",
        price: 50000,
        isAvailable: true,
      });

      const res = await request(app)
        .post("/api/cart/validate")
        .send({ items: [{ foodId: 1, quantity: 2 }] });

      expect(res.statusCode).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.totalPrice).toBe(100000);
      expect(res.body.items[0].isValid).toBe(true);
    });

    it("POST /api/cart/checkout should return 400 when missing paymentIntentId", async () => {
      const res = await request(app)
        .post("/api/cart/checkout")
        .send({ items: [{ foodId: 1 }], totalPaid: 50000 });

      expect(res.statusCode).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.message).toBe("Missing paymentIntentId");
    });

    it("POST /api/cart/checkout should successfully create order", async () => {
      prisma.order.create.mockResolvedValueOnce({
        id: "order_123",
        totalPaid: 100000,
        paymentStatus: "paid",
      });

      const res = await request(app)
        .post("/api/cart/checkout")
        .send({
          items: [{ foodId: 1, quantity: 2 }],
          paymentIntentId: "pi_test_123",
          totalPaid: 100000,
          currency: "vnd",
        });

      expect(res.statusCode).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.order.id).toBe("order_123");
    });
  });

  describe("Payment API (/api/payments)", () => {
    it("POST /api/payments/create-payment-intent with amount=0 should return checkout session", async () => {
      const res = await request(app)
        .post("/api/payments/create-payment-intent")
        .send({ amount: 0 });

      expect(res.statusCode).toBe(200);
      expect(res.body.free).toBe(true);
      expect(res.body.url).toBe("https://stripe.test/session");
    });

    it("POST /api/payments/create-payment-intent with amount > 0 should return clientSecret", async () => {
      const res = await request(app)
        .post("/api/payments/create-payment-intent")
        .send({ amount: 230000 });

      expect(res.statusCode).toBe(200);
      expect(res.body.free).toBe(false);
      expect(res.body.clientSecret).toBe("pi_secret_test123");
    });
  });

  describe("Unknown Route", () => {
    it("should return 404 for nonexistent endpoint", async () => {
      const res = await request(app).get("/api/not-a-real-endpoint");
      expect(res.statusCode).toBe(404);
    });
  });
});

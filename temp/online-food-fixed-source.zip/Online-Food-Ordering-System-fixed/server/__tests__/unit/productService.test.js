const productService = require("../../services/productService");
const { PrismaClient } = require("@prisma/client");

jest.mock("@prisma/client", () => {
  const mPrisma = {
    food: {
      findMany: jest.fn(),
      count: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
  };
  return { PrismaClient: jest.fn(() => mPrisma) };
});

const prisma = new PrismaClient();

describe("Product Service Unit Tests", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("listFoodItems", () => {
    test("should return paginated data with default parameters", async () => {
      const mockFoods = [
        { id: 1, name: "Burger", price: 50000, category: "Fast Food" },
        { id: 2, name: "Pizza", price: 120000, category: "Fast Food" },
      ];
      prisma.food.findMany.mockResolvedValue(mockFoods);
      prisma.food.count.mockResolvedValue(2);

      const result = await productService.listFoodItems({});

      expect(result.data).toEqual(mockFoods);
      expect(result.total).toBe(2);
      expect(result.page).toBe(1);
      expect(result.totalPages).toBe(1);
      expect(prisma.food.findMany).toHaveBeenCalledWith({
        skip: 0,
        take: 12,
        where: {},
        orderBy: { id: "asc" },
      });
    });

    test("should filter by category and search keyword", async () => {
      prisma.food.findMany.mockResolvedValue([]);
      prisma.food.count.mockResolvedValue(0);

      const result = await productService.listFoodItems({
        page: 2,
        limit: 5,
        category: "Drinks",
        search: "Coffee",
      });

      expect(result.data).toEqual([]);
      expect(result.page).toBe(2);
      expect(result.totalPages).toBe(0);
      expect(prisma.food.findMany).toHaveBeenCalledWith({
        skip: 5,
        take: 5,
        where: {
          category: "Drinks",
          name: { contains: "Coffee" },
        },
        orderBy: { id: "asc" },
      });
    });
  });

  describe("getFoodItemById", () => {
    test("should call findUnique with numeric id", async () => {
      const mockFood = { id: 1, name: "Sushi", price: 150000 };
      prisma.food.findUnique.mockResolvedValue(mockFood);

      const result = await productService.getFoodItemById("1");

      expect(result).toEqual(mockFood);
      expect(prisma.food.findUnique).toHaveBeenCalledWith({
        where: { id: 1 },
      });
    });

    test("should return null if item is not found", async () => {
      prisma.food.findUnique.mockResolvedValue(null);

      const result = await productService.getFoodItemById(999);

      expect(result).toBeNull();
    });
  });

  describe("createFoodItem", () => {
    test.each([["true", true], ["false", false]])("normalizes availability %s for the MySQL Boolean column", async (input, expected) => {
      await productService.createFoodItem({ name: "Food", isAvailable: input });
      expect(prisma.food.create).toHaveBeenCalledWith({ data: { name: "Food", isAvailable: expected } });
    });
    test("does not treat the string false as available when updating food", async () => {
      await productService.updateFoodItem(1, { isAvailable: "false" });
      expect(prisma.food.update).toHaveBeenCalledWith({ where: { id: 1 }, data: { isAvailable: false } });
    });
    test("should create and return the new food item", async () => {
      const newFoodData = {
        name: "Pasta",
        price: 85000,
        category: "Italian",
        isAvailable: true,
      };
      prisma.food.create.mockResolvedValue({ id: 3, ...newFoodData });

      const result = await productService.createFoodItem(newFoodData);

      expect(result).toEqual({ id: 3, ...newFoodData });
      expect(prisma.food.create).toHaveBeenCalledWith({ data: newFoodData });
    });
  });

  describe("updateFoodItem", () => {
    test("should update food item by id with numeric conversion", async () => {
      const updateData = { price: 95000 };
      prisma.food.update.mockResolvedValue({
        id: 3,
        name: "Pasta",
        price: 95000,
      });

      const result = await productService.updateFoodItem("3", updateData);

      expect(result.price).toBe(95000);
      expect(prisma.food.update).toHaveBeenCalledWith({
        where: { id: 3 },
        data: updateData,
      });
    });
  });

  describe("deleteFoodItem", () => {
    test("should delete food item by id", async () => {
      prisma.food.delete.mockResolvedValue({ id: 3, name: "Pasta" });

      const result = await productService.deleteFoodItem("3");

      expect(result).toEqual({ id: 3, name: "Pasta" });
      expect(prisma.food.delete).toHaveBeenCalledWith({
        where: { id: 3 },
      });
    });
  });

  describe("getCategories", () => {
    test("should return list of unique category names", async () => {
      prisma.food.findMany.mockResolvedValue([
        { category: "Fast Food" },
        { category: "Drinks" },
        { category: "Dessert" },
      ]);

      const result = await productService.getCategories();

      expect(result).toEqual(["Fast Food", "Drinks", "Dessert"]);
      expect(prisma.food.findMany).toHaveBeenCalledWith({
        distinct: ["category"],
        select: { category: true },
      });
    });
  });
});

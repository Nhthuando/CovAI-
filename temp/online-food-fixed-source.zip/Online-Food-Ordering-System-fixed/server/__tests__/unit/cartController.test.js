const cartController = require("../../controllers/cartController");
const { PrismaClient } = require("@prisma/client");

jest.mock("@prisma/client", () => {
  const mPrisma = {
    food: {
      findUnique: jest.fn(),
    },
    order: {
      create: jest.fn(),
    },
  };
  return { PrismaClient: jest.fn(() => mPrisma) };
});

const prisma = new PrismaClient();

describe("Cart Controller Unit Tests", () => {
  let req, res;

  beforeEach(() => {
    req = { body: {} };
    res = {
      json: jest.fn().mockReturnThis(),
      status: jest.fn().mockReturnThis(),
    };
    jest.clearAllMocks();
  });

  describe("validateCart", () => {
    it("should return empty list and 0 total when cart has no items", async () => {
      req.body = { items: [] };

      await cartController.validateCart(req, res);

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        items: [],
        totalPrice: 0,
      });
    });

    it("should validate and calculate total for available items", async () => {
      req.body = {
        items: [
          { foodId: 1, quantity: 2 },
          { foodId: 2, quantity: 1 },
        ],
      };

      prisma.food.findUnique
        .mockResolvedValueOnce({ id: 1, price: 50000, isAvailable: true })
        .mockResolvedValueOnce({ id: 2, price: 30000, isAvailable: true });

      await cartController.validateCart(req, res);

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        items: [
          {
            foodId: 1,
            quantity: 2,
            isValid: true,
            price: 50000,
            subtotal: 100000,
          },
          {
            foodId: 2,
            quantity: 1,
            isValid: true,
            price: 30000,
            subtotal: 30000,
          },
        ],
        totalPrice: 130000,
      });
    });

    it("should mark item as invalid when food is not found", async () => {
      req.body = { items: [{ foodId: 999, quantity: 1 }] };
      prisma.food.findUnique.mockResolvedValueOnce(null);

      await cartController.validateCart(req, res);

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        items: [
          {
            foodId: 999,
            quantity: 1,
            isValid: false,
            reason: "Food not found",
          },
        ],
        totalPrice: 0,
      });
    });

    it("should mark item as invalid when food is not available", async () => {
      req.body = { items: [{ foodId: 1, quantity: 1 }] };
      prisma.food.findUnique.mockResolvedValueOnce({
        id: 1,
        price: 50000,
        isAvailable: false,
      });

      await cartController.validateCart(req, res);

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        items: [
          {
            foodId: 1,
            quantity: 1,
            isValid: false,
            reason: "Food not available",
          },
        ],
        totalPrice: 0,
      });
    });

    it("should return 500 if an error occurs", async () => {
      req.body = { items: [{ foodId: 1, quantity: 1 }] };
      prisma.food.findUnique.mockRejectedValueOnce(
        new Error("Database connection lost"),
      );

      await cartController.validateCart(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: "Database connection lost",
      });
    });
  });

  describe("checkout", () => {
    it("should return 400 if paymentIntentId is missing", async () => {
      req.body = {
        items: [{ foodId: 1, quantity: 1 }],
        totalPaid: 50000,
      };

      await cartController.checkout(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: "Missing paymentIntentId",
      });
    });

    it("should successfully create order and return 200", async () => {
      const orderPayload = {
        items: [{ foodId: 1, quantity: 2 }],
        paymentIntentId: "pi_12345",
        totalPaid: 100000,
        currency: "vnd",
      };
      req.body = orderPayload;

      const createdOrder = {
        id: "order_1",
        ...orderPayload,
        totalVnd: 100000,
        paymentMethod: "stripe",
        paymentStatus: "paid",
      };
      prisma.order.create.mockResolvedValueOnce(createdOrder);

      await cartController.checkout(req, res);

      expect(prisma.order.create).toHaveBeenCalledWith({
        data: {
          items: orderPayload.items,
          totalVnd: 100000,
          totalPaid: 100000,
          currency: "vnd",
          paymentIntentId: "pi_12345",
          paymentMethod: "stripe",
          paymentStatus: "paid",
        },
      });
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        order: createdOrder,
      });
    });

    it("should return 500 if order creation fails", async () => {
      req.body = {
        items: [],
        paymentIntentId: "pi_failed",
        totalPaid: 50000,
      };
      prisma.order.create.mockRejectedValueOnce(
        new Error("Order creation failed"),
      );
      const consoleSpy = jest
        .spyOn(console, "log")
        .mockImplementation(() => {});

      await cartController.checkout(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: "Order creation failed",
      });
      consoleSpy.mockRestore();
    });
  });
});

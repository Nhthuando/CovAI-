const productControllers = require("../../controllers/productControllers");
const productService = require("../../services/productService");

jest.mock("../../services/productService");

describe("Product Controllers Unit Tests", () => {
  let req, res;

  beforeEach(() => {
    req = { query: {}, params: {}, body: {} };
    res = {
      json: jest.fn().mockReturnThis(),
      status: jest.fn().mockReturnThis(),
    };
    jest.clearAllMocks();
  });

  describe("listFoodItems", () => {
    it("should return food list with status 200", async () => {
      req.query = {
        page: "2",
        limit: "10",
        category: "Pizza",
        search: "Cheese",
      };
      const mockResult = { data: [{ id: 1, name: "Cheese Pizza" }], total: 1 };
      productService.listFoodItems.mockResolvedValue(mockResult);

      await productControllers.listFoodItems(req, res);

      expect(productService.listFoodItems).toHaveBeenCalledWith({
        page: 2,
        limit: 10,
        category: "Pizza",
        search: "Cheese",
      });
      expect(res.json).toHaveBeenCalledWith(mockResult);
    });

    it("should handle error with 500 status", async () => {
      productService.listFoodItems.mockRejectedValue(new Error("DB error"));
      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      await productControllers.listFoodItems(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Internal Server Error" });
      consoleSpy.mockRestore();
    });
  });

  describe("getFoodItems", () => {
    it("should return food item if found", async () => {
      req.params.id = "1";
      const mockFood = { id: 1, name: "Burger" };
      productService.getFoodItemById.mockResolvedValue(mockFood);

      await productControllers.getFoodItems(req, res);

      expect(productService.getFoodItemById).toHaveBeenCalledWith("1");
      expect(res.json).toHaveBeenCalledWith(mockFood);
    });

    it("should return 404 if item not found", async () => {
      req.params.id = "999";
      productService.getFoodItemById.mockResolvedValue(null);

      await productControllers.getFoodItems(req, res);

      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith({ message: "Food item not found" });
    });

    it("should return 500 on service exception", async () => {
      req.params.id = "1";
      productService.getFoodItemById.mockRejectedValue(new Error("Error"));
      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      await productControllers.getFoodItems(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Internal Server Error" });
      consoleSpy.mockRestore();
    });
  });

  describe("createFoodItems", () => {
    it("should create item and return 201", async () => {
      req.body = { name: "Salad", price: 40000 };
      const createdFood = { id: 10, ...req.body };
      productService.createFoodItem.mockResolvedValue(createdFood);

      await productControllers.createFoodItems(req, res);

      expect(productService.createFoodItem).toHaveBeenCalledWith(req.body);
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith(createdFood);
    });

    it("should return 500 on creation error", async () => {
      productService.createFoodItem.mockRejectedValue(new Error("Failed"));
      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      await productControllers.createFoodItems(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Internal Server Error" });
      consoleSpy.mockRestore();
    });
  });

  describe("updateFoodItems", () => {
    it("should update item and return updated data", async () => {
      req.params.id = "5";
      req.body = { price: 60000 };
      const updatedFood = { id: 5, name: "Juice", price: 60000 };
      productService.updateFoodItem.mockResolvedValue(updatedFood);

      await productControllers.updateFoodItems(req, res);

      expect(productService.updateFoodItem).toHaveBeenCalledWith("5", req.body);
      expect(res.json).toHaveBeenCalledWith(updatedFood);
    });

    it("should return 500 on update error", async () => {
      req.params.id = "5";
      productService.updateFoodItem.mockRejectedValue(new Error("Failed"));
      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      await productControllers.updateFoodItems(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Internal Server Error" });
      consoleSpy.mockRestore();
    });
  });

  describe("deleteFoodItems", () => {
    it("should delete item and return success message", async () => {
      req.params.id = "5";
      productService.deleteFoodItem.mockResolvedValue({});

      await productControllers.deleteFoodItems(req, res);

      expect(productService.deleteFoodItem).toHaveBeenCalledWith("5");
      expect(res.json).toHaveBeenCalledWith({
        message: "Food item deleted successfully",
      });
    });

    it("should return 500 on delete error", async () => {
      req.params.id = "5";
      productService.deleteFoodItem.mockRejectedValue(new Error("Failed"));
      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      await productControllers.deleteFoodItems(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Internal Server Error" });
      consoleSpy.mockRestore();
    });
  });

  describe("getCategoriesController", () => {
    it("should return category list", async () => {
      const mockCategories = ["Pizza", "Burgers", "Drinks"];
      productService.getCategories.mockResolvedValue(mockCategories);

      await productControllers.getCategoriesController(req, res);

      expect(res.json).toHaveBeenCalledWith(mockCategories);
    });

    it("should return 500 on error", async () => {
      productService.getCategories.mockRejectedValue(new Error("Failed"));
      const consoleSpy = jest
        .spyOn(console, "error")
        .mockImplementation(() => {});

      await productControllers.getCategoriesController(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Internal Server Error" });
      consoleSpy.mockRestore();
    });
  });
});

const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();
const { PrismaClient } = require("@prisma/client");
const foodRoutes = require("./routes/productRoutes");
const cardRoutes = require("./routes/cartRoutes");
const paymentRoutes = require("./routes/paymentRoutes");

const app = express();
const prisma = new PrismaClient();

app.use(
  cors({
    origin: true,
    credentials: true,
  }),
);

app.use(express.json());

// --- Test route ---
app.get("/", (req, res) => {
  res.send("API server is running...");
});

// --- Correct way to use router ---
app.use("/api/food-items", foodRoutes);
app.use("/api/cart", cardRoutes);
app.use("/api/payments", paymentRoutes);

// --- Start server ---
if (process.env.NODE_ENV !== "test") {
  prisma
    .$connect()
    .then(() => {
        const port = Number(process.env.PORT || 3000);
        app.listen(port, () => {
          console.log(`Server running on http://localhost:${port}`);
      });
    })
    .catch((err) => {
      console.error("Error connecting to database:", err);
    });
}

module.exports = app;
